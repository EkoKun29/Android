package com.example.spmpkl;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.spmpkl.databinding.MahasiswaNavHeaderMahasiswaBinding;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.spmpkl.databinding.MahasiswaActivityMahasiswaBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class MahasiswaActivity extends AppCompatActivity {

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("users");

    TextView text_name, text_npm, text_alamat;



    private AppBarConfiguration mAppBarConfiguration;
    private MahasiswaActivityMahasiswaBinding binding;


    private NavigationView nav_view;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = MahasiswaActivityMahasiswaBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());

        //txt_name = findViewById(R.id.name);
        //text_npm = findViewById(R.id.username);
        //text_alamat =findViewById(R.id.apkl);
        //sharedPreferences =getSharedPreferences(DATA_AS, MODE_PRIVATE);


        setSupportActionBar(binding.appBarMahasiswa.toolbar);
        binding.appBarMahasiswa.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;

        navigationView = findViewById(R.id.nav_view);

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_presensi, R.id.nav_rekap, R.id.nav_bimbingan, R.id.nav_nilai, R.id.nav_logout)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_mahasiswa);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        gettingData();

    }

    private void gettingData() {
        Intent intent = getIntent();
        String m_username = intent.getStringExtra("Username");
        String m_name = intent.getStringExtra("Name");
        String m_alamat = intent.getStringExtra("Alamat");

        View header = binding.navView.getHeaderView(0);

        text_name = (TextView) header.findViewById(R.id.text_name);
        text_npm = (TextView)  header.findViewById(R.id.text_npm);
        text_alamat= (TextView)  header.findViewById(R.id.text_alamat);

        text_name.setText(m_name);
        text_npm.setText(m_username);
        text_alamat.setText(m_alamat);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.mahasiswa, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_mahasiswa);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    public void logout(MenuItem item){
        startActivity(new Intent(MahasiswaActivity.this, LoginActivity.class));
        preferences.clearData(this);
        finish();
    }

//    public void TextView(View view) {
//        final String Name = sharedPreferences.getString(NameTxt,null);
//        final String Username = sharedPreferences.getString(UsernameTxt, null);
//        final String Alamat = sharedPreferences.getString(AlamatTxt,null);
//        preferences.getDataAs(this);
//        finish();
//
//        databaseReference.child("users").child("Name").child("Username").child("Alamat").
//                addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if(Name != null || Username !=null && Alamat !=null ){
//                    text_name.setText("" + Name);
//                    text_npm.setText("" + Username);
//                    text_alamat.setText("" + Alamat);
//
//
//                }
//
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//
//
//
//        //preferences.getDataAs(this);
//        //preferences.setDataAs(this,"npm");
//        //preferences.setDataAs(this,"username");
//        //preferences.setDataAs(this,"users" );
//        //finish();
//
//    }

}