package com.example.spmpkl;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.jar.Attributes;

public class RegisterActivity extends AppCompatActivity {

    SharedPreferences sharedPreferences;


    DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReferenceFromUrl("https://spmpkl-567fc-default-rtdb.firebaseio.com/");
    private StorageReference storage = FirebaseStorage.getInstance().getReferenceFromUrl("gs://spmpkl-567fc.appspot.com");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final EditText Name = findViewById(R.id.name);
        final EditText Alamat = findViewById(R.id.apkl);
        final EditText Dosbing = findViewById(R.id.dp);
        final EditText Username = findViewById(R.id.username);
        final EditText Password = findViewById(R.id.password);
        final EditText PasswordConf = findViewById(R.id.password_conf);
        final Button btnRegister = findViewById(R.id.btn_register);
        final TextView btnLogin = findViewById(R.id.btn_login);

        final ImageView image = findViewById(R.id.imageView);
       /* Intent intent = getIntent();
        if (intent.hasExtra("image")){
            String uri = intent.getStringExtra("image");

        }*/

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(RegisterActivity.this, UploadFotoActivity.class);
                startActivity(intent);

            }
        });
        storage.child("users").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(image);
            }
        });



      sharedPreferences = getSharedPreferences("users",0);

        btnRegister.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   final String NameTxt= Name.getText().toString();
                   final String AlamatTxt= Alamat.getText().toString();
                    final String DosbingTxt= Dosbing.getText().toString();
                   final String UsernameTxt= Username.getText().toString();
                   final String PasswordTxt= Password.getText().toString();
                   final String PasswordConfTxt= PasswordConf.getText().toString();



                   if(NameTxt.isEmpty() || AlamatTxt.isEmpty() || DosbingTxt.isEmpty() || UsernameTxt.isEmpty() || PasswordTxt.isEmpty() || PasswordConfTxt.isEmpty() ){
                       Toast.makeText(RegisterActivity.this, "Silahkan Isi Semua Data", Toast.LENGTH_SHORT).show();

                   }
                   else if (!PasswordTxt.equals(PasswordConfTxt)){
                       Toast.makeText(RegisterActivity.this, "Password Tidak Cocok", Toast.LENGTH_SHORT).show();
                   }
                   else{
                       databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                           @Override
                           public void onDataChange(@NonNull DataSnapshot snapshot) {

                               if(snapshot.hasChild(UsernameTxt)){

                                   SharedPreferences.Editor editor = sharedPreferences.edit();
                                   /*Picasso.get().load(uri).into(image);
                                   int image_link = getIntent().getIntExtra("url", R.id.imageView);
                                   image.setImageResource(image_link);*/
                                   editor.putString("Name", NameTxt);
                                   editor.putString("Alamat", AlamatTxt);
                                   editor.putString("Dosbing", DosbingTxt);
                                   editor.putString("Username", UsernameTxt);
                                   editor.putString("Password", PasswordTxt);
                                   editor.putString("PasswordConf", PasswordConfTxt);
                                   editor.apply();
                                   Toast.makeText(RegisterActivity.this, "Username Sudah Di Registrasi", Toast.LENGTH_SHORT).show();
                               }
                               else{

                                   databaseReference.child("users").child(UsernameTxt).child("Name").setValue(NameTxt);
                                   databaseReference.child("users").child(UsernameTxt).child("Alamat").setValue(AlamatTxt);
                                   databaseReference.child("users").child(UsernameTxt).child("Dosbing").setValue(DosbingTxt);
                                   databaseReference.child("users").child(UsernameTxt).child("Username").setValue(UsernameTxt);
                                   databaseReference.child("users").child(UsernameTxt).child("Password").setValue(PasswordTxt);

                                   Toast.makeText(RegisterActivity.this, "Registrasi Sukses", Toast.LENGTH_SHORT).show();
                                   finish();
                               }
                           }

                           @Override
                           public void onCancelled(@NonNull DatabaseError error) {

                           }
                       });




                   }
                }
            });
            btnLogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
                });

    }


    private void register(String name, String npm, String password){

        preferences.setDataAs(this,"name");
        preferences.setDataAs(this,"npm");
        preferences.setDataAs(this,"username");
    }
    private void reload(){

        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
    }


}