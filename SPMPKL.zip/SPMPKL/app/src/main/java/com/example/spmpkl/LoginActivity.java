package com.example.spmpkl;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    SharedPreferences sharedPreferences;

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://spmpkl-567fc-default-rtdb.firebaseio.com/");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final EditText Username = findViewById(R.id.username);
        final EditText Password = findViewById(R.id.password);
        final Button btnLogin= findViewById(R.id.btn_login);
        final TextView btnRegister = findViewById(R.id.btn_register);

        sharedPreferences = getSharedPreferences("users",0);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String usernametxt = Username.getText().toString();
                final String passwordtxt = Password.getText().toString();





                if(usernametxt.isEmpty() || passwordtxt.isEmpty()){
                    Toast.makeText(LoginActivity.this, "Masukkan Username Atau Password", Toast.LENGTH_SHORT).show();
                }
                else {
                    databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.hasChild(usernametxt)) {

                                final String getPassword = snapshot.child(usernametxt).child("Password").getValue(String.class);
                                final String getname = snapshot.child(usernametxt).child("Name").getValue(String.class);
                                if (getPassword.equals(passwordtxt)) {

                                    Toast.makeText(LoginActivity.this, "Login Sukses "+ getname, Toast.LENGTH_SHORT).show();

                                    if (usernametxt.length()==8){
                                        final String name = snapshot.child(usernametxt).child("Name").getValue(String.class);
                                        final String username = snapshot.child(usernametxt).child("Username").getValue(String.class);
                                        final String alamat = snapshot.child(usernametxt).child("Alamat").getValue(String.class);
                                        final String dosbing = snapshot.child(usernametxt).child("Dosbing").getValue(String.class);

                                        Intent intent = new Intent(LoginActivity.this,MahasiswaActivity.class);
                                        intent.putExtra("Name", name);
                                        intent.putExtra("Username", username);
                                        intent.putExtra("Alamat", alamat);
                                        intent.putExtra("Dosbing", dosbing);
                                        startActivity(intent);
                                        finish();




                                    }else {
                                        if (usernametxt.length()==3) {
                                            final String name = snapshot.child(usernametxt).child("Name").getValue(String.class);

                                            Intent intent = new Intent(LoginActivity.this,AdminActivity.class);
                                            intent.putExtra("Name", name);

                                            startActivity(intent);
                                            finish();
                                        }
                                        else{

                                            if (usernametxt.length()==10){
                                                final String name = snapshot.child(usernametxt).child("Name").getValue(String.class);
                                                final String username = snapshot.child(usernametxt).child("Username").getValue(String.class);


                                                Intent intent = new Intent(LoginActivity.this,DosenActivity.class);
                                                intent.putExtra("Name", name);
                                                intent.putExtra("Username", username);

                                                startActivity(intent);
                                                finish();

                                            }else{
                                                final String name = snapshot.child(usernametxt).child("Name").getValue(String.class);
                                                final String username = snapshot.child(usernametxt).child("Username").getValue(String.class);


                                                Intent intent = new Intent(LoginActivity.this,PelapActivity.class);
                                                intent.putExtra("Name", name);
                                                intent.putExtra("Username", username);

                                                startActivity(intent);
                                                finish();

                                            }

                                        }
                                        /*final String name = snapshot.child(usernametxt).child("Name").getValue(String.class);
                                        final String username = snapshot.child(usernametxt).child("Username").getValue(String.class);


                                        Intent intent = new Intent(LoginActivity.this,DosenActivity.class);
                                        intent.putExtra("Name", name);
                                        intent.putExtra("Username", username);

                                        startActivity(intent);
                                        finish();*/

                                    }

                                } else {
                                    Toast.makeText(LoginActivity.this, "Password Salah", Toast.LENGTH_SHORT).show();
                                }
                            }
                            else{
                                Toast.makeText(LoginActivity.this, "Password Salah", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }

            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });


    }
}