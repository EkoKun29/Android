package com.example.spmpkl;

public class Model {

    private String imageUrl;

    public Model(String imageUrl){
        this.imageUrl = imageUrl;

    }


}
