package com.example.spmpkl.ui.data_nilai;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.spmpkl.databinding.AdminFragmentDatanilaiBinding;



public class DatanilaiFragment extends Fragment {

    private AdminFragmentDatanilaiBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        DatanilaiViewModel notificationsViewModel =
                new ViewModelProvider(this).get(DatanilaiViewModel.class);

        binding = AdminFragmentDatanilaiBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textNotifications;
        notificationsViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}