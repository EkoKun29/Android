package com.example.spmpkl.ui_mahasiswa.home;

import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.TextView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.spmpkl.R;
import com.example.spmpkl.preferences;

public class MahasiswaHomeViewModel extends ViewModel {


    public MahasiswaHomeViewModel() {





    }
    private void gettingData(){



    }

    //public LiveData<String> getText() {
        //return mText;
    }
//}