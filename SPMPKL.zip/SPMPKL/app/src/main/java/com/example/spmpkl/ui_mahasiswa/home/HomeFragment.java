package com.example.spmpkl.ui_mahasiswa.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.spmpkl.R;
import com.example.spmpkl.databinding.MahasiswaFragmentHomeBinding;
import com.example.spmpkl.databinding.DosenFragmentHomeBinding;
import com.google.firebase.database.DatabaseReference;

public class HomeFragment extends Fragment {
DatabaseReference reference;
ImageView imageProfile;
TextView text_name, text_npm, text_alamat, text_dosbing;


    private MahasiswaFragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //MahasiswaHomeViewModel homeViewModel = new ViewModelProvider(this).get(MahasiswaHomeViewModel.class);
        binding = MahasiswaFragmentHomeBinding.inflate(inflater, container, false);
        //View m_view = inflater.inflate(R.layout.mahasiswa_fragment_home, container, false);

        text_name = binding.textName;
        text_npm =   binding.textNpm;
       /* text_alamat= binding.textAlamat;
        text_dosbing = binding.textDosbing;*/



        String m_username = getActivity().getIntent().getStringExtra("Username");
        String m_name = getActivity().getIntent().getStringExtra("Name");
        String m_alamat =getActivity().getIntent().getStringExtra("Alamat");
        String m_dosbing = getActivity().getIntent().getStringExtra("Dosbing");


        text_name.setText(m_name);
        text_npm.setText(m_username);
      /*  text_alamat.setText(m_alamat);
        text_dosbing.setText(m_dosbing);*/




        View view = binding.getRoot();

        final TextView textView = binding.textHome;

       // gettingData();
        //homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return view;


    }
   /* private void gettingData() {


        View view = binding.navView.();





    }*/

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}